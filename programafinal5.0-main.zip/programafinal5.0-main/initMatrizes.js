function initMatrizes( pontos, conexoes ) {
    let n = pontos.length
    let grausdeliberdade = n * 3

    // inicio programa
    let K = criarMatrizdeRigidezVazia( grausdeliberdade )
    preencherMatrizGlobaldeRigidez( K )
    let F = criarMatrizdeEsforcoVazia( grausdeliberdade )
    preencherMatrizGlobaldeEsforco( F )
    let U = criarMatrizdeDeformacaoVazia( grausdeliberdade )
    let matrizes = criarMatrizesdeRigidezElementares( conexoes )
    montagemMatrizesGlobais_Assembly( K, F, matrizes )

    adicionarCondicoesdeContorno( U )
    adicionarEsforcosExternos( F )

    adicionarEsforcosExternos( F )
    verificarConvergencia( K, U, F )
    
    let vetores = modulosDosVetores( U )
    // final programa



    function criarMatrizdeRigidezVazia( grausdeliberdade ) {
        let k = new Array( grausdeliberdade )
        for ( let i = 0; i < grausdeliberdade; i++ ) { k[i]   = new Array( grausdeliberdade ) }
        return k
    }
    function criarMatrizdeEsforcoVazia( grausdeliberdade ) {
        let f = new Array( grausdeliberdade )
        return f
    }
    function criarMatrizdeDeformacaoVazia( grausdeliberdade ) {
        let U = new Array( grausdeliberdade )
        for ( let i = 0; i < U.length; i++ ) {
            U[i] = { valor: 1, identificado: 'none' }
        }
        return U
    }
    function preencherMatrizGlobaldeRigidez( k ) {
        for ( let i = 0; i < k.length; i++ ) { 
            for ( let j = 0; j < k.length; j++ ) { 
                k[i][j] = 0
            }
        }
    }
    function preencherMatrizGlobaldeEsforco( f ) {
        for ( let i = 0; i < f.length; i++ ) { 
            f[i] = 0
        }
    }

    function criarMatrizesdeRigidezElementares( conexoes ) {
        console.log( 'Criando Matrizes K dos Elementos...' )
        let matrizes = []
        let index = 0
        for ( let conexao of conexoes ) {
            index++
            matrizes.push( criarMatrizdeRigidez( conexao ) )
            console.log( `Progresso: ${index} | %c${conexoes.length}`, 'color: white; background-color: gray;' )
        }
        console.log( '... as Matrizes K dos Elementos foram Criadas.' )
        return matrizes    
    }
    function criarMatrizdeRigidez( conexao ) {
        let a = ( conexao.pontoA.id ) 
        let b = ( conexao.pontoB.id )

        let k = criarMatrizdeRigidezVazia( grausdeliberdade )
        let kij = calcularMatrizdeRigidez( conexao.pontoA.pos, conexao.pontoB.pos )
        let f = criarMatrizdeEsforcoVazia( grausdeliberdade )
        let fi = calcularVetordeEsforco()

        let ua = (a * 3)
        let ub = (b * 3)
        let va = (a * 3) + 1
        let vb = (b * 3) + 1
        let wa = (a * 3) + 2
        let wb = (b * 3) + 2

        k[ua][ua] = kij.k11
        k[ua][va] = kij.k12
        k[ua][wa] = kij.k13
        k[ua][ub] = kij.k14
        k[ua][vb] = kij.k15
        k[ua][wb] = kij.k16

        k[va][ua] = kij.k21
        k[va][va] = kij.k22
        k[va][wa] = kij.k23
        k[va][ub] = kij.k24
        k[va][vb] = kij.k25
        k[va][wb] = kij.k26

        k[wa][ua] = kij.k31
        k[wa][va] = kij.k32
        k[wa][wa] = kij.k33
        k[wa][ub] = kij.k34
        k[wa][vb] = kij.k35
        k[wa][wb] = kij.k36

        k[ub][ua] = kij.k41
        k[ub][va] = kij.k42
        k[ub][wa] = kij.k43
        k[ub][ub] = kij.k44
        k[ub][vb] = kij.k45
        k[ub][wb] = kij.k46

        k[vb][ua] = kij.k51
        k[vb][va] = kij.k52
        k[vb][wa] = kij.k53
        k[vb][ub] = kij.k54
        k[vb][vb] = kij.k55
        k[vb][wb] = kij.k56

        k[wb][ua] = kij.k61
        k[wb][va] = kij.k62
        k[wb][wa] = kij.k63
        k[wb][ub] = kij.k64
        k[wb][vb] = kij.k65
        k[wb][wb] = kij.k66

        f[ua] = fi.f1
        f[va] = fi.f2
        f[wa] = fi.f3
        f[ub] = fi.f4
        f[vb] = fi.f5
        f[wb] = fi.f6

        return {k, f}
    }
    function calcularMatrizdeRigidez( posA, posB ) {
        let E = 10
        let A = 2
        let k = E*A

        let [xa, ya, za] = posA
        let [xb, yb, zb] = posB

        let lo = Math.sqrt( (xa-xb)**2 + (ya-yb)**2 + (za-zb)**2 )
        let l = ( ( xb - xa )/lo )
        let m = ( ( yb - ya )/lo )
        let n = ( ( zb - za )/lo )

        let kij = {
            k11: k*(l*l)/lo, k12: k*(l*m)/lo, k13: k*(l*n)/lo, k14:-k*(l*l)/lo, k15:-k*(l*m)/lo, k16:-k*(l*n)/lo,
            k21: k*(m*l)/lo, k22: k*(m*m)/lo, k23: k*(m*n)/lo, k24:-k*(m*l)/lo, k25:-k*(m*m)/lo, k26:-k*(m*n)/lo,
            k31: k*(n*l)/lo, k32: k*(n*m)/lo, k33: k*(n*n)/lo, k34:-k*(n*l)/lo, k35:-k*(n*m)/lo, k36:-k*(n*n)/lo,
            k41:-k*(l*l)/lo, k42:-k*(l*m)/lo, k43:-k*(l*n)/lo, k44: k*(l*l)/lo, k45: k*(l*m)/lo, k46: k*(l*n)/lo,
            k51:-k*(m*l)/lo, k52:-k*(m*m)/lo, k53:-k*(m*n)/lo, k54: k*(m*l)/lo, k55: k*(m*m)/lo, k56: k*(m*n)/lo,
            k61:-k*(n*l)/lo, k62:-k*(n*m)/lo, k63:-k*(n*n)/lo, k64: k*(m*l)/lo, k65: k*(n*m)/lo, k66: k*(n*n)
        }

        return kij
    }
    function calcularVetordeEsforco() {
        let p = 1
        let fi = { f1: p, f2: p, f3: p, f4: p, f5: p, f6: p }
        return fi
    }

    function montagemMatrizesGlobais_Assembly( K, F, matrizes ) {
        console.log( 'Iniciando Assembly da matriz K Global...' )
        let index = 0
        for ( let matriz of matrizes ) {
            for ( let i in K ) {
                if ( matriz.f[i] ) { F[i] += matriz.f[i] }
                for ( let j in K ) {
                    if ( matriz.k[i][j] ) { 
                        index++
                        K[i][j] += (matriz.k[i][j]) 
                        console.log( `Progresso: ${index} | %c${6*matrizes.length}`, 'color: white; background-color: black;' )
                    }
                    
                }
            }
        } 
        console.log( '... o Assembly da matriz K Global foi concluido.' )
    }
    function adicionarCondicoesdeContorno( U ) {
        console.log( 'Adicionando Condições de Contorno...' )
        for ( let i = 0; i < Math.floor((n*3)/8); i++ ) {
            let r = Math.floor( Math.random() * n )
            U[3*r] = { valor: 0, identificado: true }
            U[3*r+1] = { valor: 0, identificado: true } 
            U[3*r+2] = { valor: 0, identificado: true } 
        }
        console.log( '... as Condições de Contorno foram adicionadas.' )
    }
    function adicionarEsforcosExternos() {
        console.log( 'Adicionando Carregamentos Externos...' )
        /*
        F[0] += 3
        F[1] += 3
        F[2] += 3
        */
        console.log( '... os Carregamentos Externos foram adicionados.' )
    }

    function calcularDeformacoes( K, U, F ) {
        for ( let i in K ) {
            if ( U[i].identificado == 'none' ) {
                let T = 0
                for ( let j in K ) { T += (K[i][j] * U[j].valor) }
                let u =  (1/K[i][i])*( - F[i] - ( T - (K[i][i]*U[i].valor) ) )
                U[i].valor = u
            }
        }

    }

    function verificarConvergencia( K, U, F ) {
        let e = 0
        let erro = grausdeliberdade
        for ( let i in K ) {
            if ( U[i].identificado == 'none' ) {
                let T = 0
                for ( let j in K ) {T += (K[i][j] * U[j].valor) }
                e += (T + F[i])
            }
        }

        e = Math.abs( e )

        if ( e >= erro ) {
            console.log(`erro | %c${e}`,'color: white; background-color: red;')
            calcularDeformacoes( K, U, F )
            verificarConvergencia( K, U, F )

        } else {
            for ( let i in U ) {
                U[i].identificado = 'true'
            }
            console.log( `%cDEFORMAÇÃO CALCULADA COM PRECISÃO! | ${e}`, 'color: white; background-color: green;' )
        }
    }

    function modulosDosVetores( U ) {
        console.log( 'Iniciando a interpolação de cores...' )
        console.log( 'Calculando modulos de deformação...' )
        let vetores = []
        let modulos = []
        for ( let i = 0 ; i < n ; i++ ) {
            let u, v, w, abs
            u = U[ ( i * 3 ) + 0 ].valor
            v = U[ ( i * 3 ) + 1 ].valor
            w = U[ ( i * 3 ) + 2 ].valor
            abs = Math.sqrt( u * u + v * v + w * w )

            let nx, ny, nz
            nx = u / abs
            ny = v / abs
            nz = w / abs

            let dados
            if ( abs == 0 ) { dados = { vetor: { u, v, w, abs, normalizado: { nx: 0, ny: 0, nz: 0 } } } 
            } else { dados = { vetor: { u, v, w, abs, normalizado: { nx, ny, nz } } } }

            vetores.push( dados )
            modulos.push( abs )
        }
        let min = Math.min( ...modulos )
        let max = Math.max( ...modulos )

        console.log( '... os modulos de deformação foram calculados.' )
        console.log( '... a interpolação de cores foi concluida.' )
        return { vetores, min, max }
    }

    return{ K, U, F, vetores }
}

export default initMatrizes