import * as THREE from './three.module.js'

function desenharAgente( cena, agente ) {
    //console.log( 'Desenhando agente...'  )
    let index = 0
    let posicionamentoConexoes = new Float32Array( agente.path.length * 6 )
    let coresConexoes = new Uint8Array( agente.path.length * 6 )

    for ( let i in agente.path ) {
        posicionamentoConexoes[ ( 6 * i ) + 0 ] = agente.path[i].posi.x
        posicionamentoConexoes[ ( 6 * i ) + 1 ] = agente.path[i].posi.y
        posicionamentoConexoes[ ( 6 * i ) + 2 ] = agente.path[i].posi.z

        posicionamentoConexoes[ ( 6 * i ) + 3 ] = agente.path[i].posf.x
        posicionamentoConexoes[ ( 6 * i ) + 4 ] = agente.path[i].posf.y
        posicionamentoConexoes[ ( 6 * i ) + 5 ] = agente.path[i].posf.z

        coresConexoes[ ( 6 * i ) + 0 ] = agente.path[i].cor.r * 255
        coresConexoes[ ( 6 * i ) + 1 ] = agente.path[i].cor.g * 255
        coresConexoes[ ( 6 * i ) + 2 ] = agente.path[i].cor.b * 255

        coresConexoes[ ( 6 * i ) + 3 ] = agente.path[i].cor.r * 255
        coresConexoes[ ( 6 * i ) + 4 ] = agente.path[i].cor.g * 255
        coresConexoes[ ( 6 * i ) + 5 ] = agente.path[i].cor.b * 255
    }

    let conexoesMaterial, conexoesGeometria, conexoesMesh
    conexoesGeometria = new THREE.BufferGeometry()
    conexoesGeometria.setAttribute( 'position', new THREE.BufferAttribute( posicionamentoConexoes, 3 ) )
    conexoesGeometria.setAttribute( 'color', new THREE.BufferAttribute( coresConexoes, 3, true ) )
    conexoesGeometria.setDrawRange( 0, agente.path.length * 6 )
    conexoesMaterial = new THREE.LineBasicMaterial({
        vertexColors: true,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: .7
    })
    conexoesMesh = new THREE.LineSegments( conexoesGeometria, conexoesMaterial )
    agente.mesh = conexoesMesh
    agente.passo = Math.floor( Math.random() * 5 )
    agente.way = 0
    cena.add( agente.mesh )

    //console.log( '... Agente desenhado' )
    
    return agente
}

export default desenharAgente