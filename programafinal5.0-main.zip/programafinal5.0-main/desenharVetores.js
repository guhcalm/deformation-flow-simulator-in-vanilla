import * as THREE from './three.module.js'

function desenharVetores( estrutura, pontos ) {
    console.log( 'Desenhando vetores...'  )


    let posicionamentoVetores = new Float32Array( pontos.length * 3 * 2 )
    let coresVetores = new Uint8Array( pontos.length * 3 * 2 )

    for ( let i in pontos ) {
        let nx, ny, nz
        
        nx = pontos[i].vetor.normalizado.nx * 5
        ny = pontos[i].vetor.normalizado.ny * 5
        nz = pontos[i].vetor.normalizado.nz * 5

        posicionamentoVetores[ ( 6 * i ) + 0 ] = pontos[i].posicionamento.x
        posicionamentoVetores[ ( 6 * i ) + 1 ] = pontos[i].posicionamento.y
        posicionamentoVetores[ ( 6 * i ) + 2 ] = pontos[i].posicionamento.z

        posicionamentoVetores[ ( 6 * i ) + 3 ] = pontos[i].posicionamento.x + nx
        posicionamentoVetores[ ( 6 * i ) + 4 ] = pontos[i].posicionamento.y + ny
        posicionamentoVetores[ ( 6 * i ) + 5 ] = pontos[i].posicionamento.z + nz
        

        coresVetores[ ( 6 * i ) + 0 ] = pontos[i].cor.r * 255
        coresVetores[ ( 6 * i ) + 1 ] = pontos[i].cor.g * 255
        coresVetores[ ( 6 * i ) + 2 ] = pontos[i].cor.b * 255

        coresVetores[ ( 6 * i ) + 3 ] = pontos[i].cor.r * 255
        coresVetores[ ( 6 * i ) + 4 ] = pontos[i].cor.g * 255
        coresVetores[ ( 6 * i ) + 5 ] = pontos[i].cor.b * 255

    }
    
    let vetoresGeometria = new THREE.BufferGeometry()
    vetoresGeometria.setAttribute( 'position', new THREE.BufferAttribute( posicionamentoVetores, 3 ) )
    vetoresGeometria.setAttribute( 'color', new THREE.BufferAttribute( coresVetores, 3, true ) )
    vetoresGeometria.setDrawRange( 0, pontos.length * 2 )

    let vetoresMaterial = new THREE.LineBasicMaterial({
        vertexColors: true,
		blending: THREE.AdditiveBlending,
		transparent: true
    })


    let mesh = new THREE.LineSegments( vetoresGeometria, vetoresMaterial )

    estrutura.add(mesh)

    console.log( '... Vetores desenhados'  )
}

export default desenharVetores