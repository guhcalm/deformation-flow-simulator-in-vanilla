import * as THREE from './three.module.js'
import parametrizarCores from './parametrizarCores.js'

function desenharGradiente( cena, malhaCelulas, malha, matrizes, raio ) {
    console.log( 'Desenhando gradiente...' )
    // organizando variaveis...
    let dx, dy, dz
    dx = malha.dimensoes.discretas.x
    dy = malha.dimensoes.discretas.y
    dz = malha.dimensoes.discretas.z

    let dm = ( dx >= dy ? ( dy >= dz ? dz : dy ) : ( dx ) )

    let pontosMaterial, pontosGeometria
    if ( malhaCelulas.length == 27 ) {} else {
        let posicionamentoPontos = new Float32Array( malhaCelulas.length * 3 )
        let coresPontos = new Uint8Array( malhaCelulas.length * 3 )
        for ( let i in malhaCelulas ) {
            posicionamentoPontos[ ( 3 * i ) + 0 ] = malhaCelulas[i].posicionamento.x
            posicionamentoPontos[ ( 3 * i ) + 1 ] = malhaCelulas[i].posicionamento.y
            posicionamentoPontos[ ( 3 * i ) + 2 ] = malhaCelulas[i].posicionamento.z
            
            if ( malhaCelulas[i].vetor == null ) {
                let r, g, b
                r = 217
                g = 164
                b = 84
                coresPontos[ ( 3 * i ) + 0 ] = Math.floor( r ) 
                coresPontos[ ( 3 * i ) + 1 ] = Math.floor( g ) 
                coresPontos[ ( 3 * i ) + 2 ] = Math.floor( b )

                pontosMaterial = new THREE.PointsMaterial({
                    vertexColors: THREE.VertexColors,
                    onBeforeCompile: shader => {
                        shader.fragmentShader = shader.fragmentShader.replace(
                        `#include <clipping_planes_fragment>`,
                        `
                        if (length(gl_PointCoord - 0.5) > 0.5 ) discard; // make points round
                        #include <clipping_planes_fragment>
                        `
                        );
                    },
                    size: dm*.03,
                    //blending: THREE.AdditiveBlending,
                    transparent: true,
                    opacity: .5
                })
            } else {
                let min, max, ut, cor
                min = matrizes.vetores.min
                max = matrizes.vetores.max
                ut =  malhaCelulas[i].vetor.abs
                cor = parametrizarCores( min, max, ut )
                coresPontos[ ( 3 * i ) + 0 ] = cor.r * 255
                coresPontos[ ( 3 * i ) + 1 ] = cor.g * 255
                coresPontos[ ( 3 * i ) + 2 ] = cor.b * 255

                pontosMaterial = new THREE.PointsMaterial({
                    vertexColors: THREE.VertexColors,
                    onBeforeCompile: shader => {
                        shader.fragmentShader = shader.fragmentShader.replace(
                        `#include <clipping_planes_fragment>`,
                        `
                        if (length(gl_PointCoord - 0.5) > 0.5 ) discard; // make points round
                        #include <clipping_planes_fragment>
                        `
                        );
                    },
                    size: dm*raio,
                    //blending: THREE.AdditiveBlending,
                    transparent: true,
                    opacity: 1
                })
            }
            
        }
        
        pontosGeometria = new THREE.BufferGeometry()
        pontosGeometria.setAttribute( 'position', new THREE.BufferAttribute( posicionamentoPontos, 3 ) )
        pontosGeometria.setAttribute( 'color', new THREE.BufferAttribute( coresPontos, 3, true ) )
        pontosGeometria.setDrawRange( 0, malhaCelulas.length )
    
        
    
    
        let mesh = new THREE.Points( pontosGeometria, pontosMaterial )
    
        cena.add(mesh)
    
    }
    
    console.log( '... Gradiente desenhado'  )
}

export default desenharGradiente