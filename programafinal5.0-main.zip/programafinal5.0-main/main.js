import * as THREE from './three.module.js'
import { GUI } from './dat.gui.module.js'
import Stats from './stats.module.js'
import { OrbitControls } from './OrbitControls.js'
import initGeometria from './initGeometria.js'
import initPontos from './initPontos.js'
import addConexoesPontos from './addConexoesPontos.js'
import deformarPontos from './deformarPontos.js'
import initConexoes from './initConexoes.js'
import initMatrizes from './initMatrizes.js'
import desenharIluminar from './desenharIluminar.js'
import desenharPontos from './desenharPontos.js'
import desenharConexoes from './desenharConexoes.js'
import desenharCelulas from './desenharCelulas.js'
import desenharVetores from './desenharVetores.js'
import adicionarCoresNosPontos from './adicionarCoresNosPontos.js'
import adicionarVetoresNosPontos from './adicionarVetoresNosPontos.js'
import initCelulas from './initCelulas.js'
import addConexoesCelulas from './addConexoesCelulas.js'
import mapearVerticesCelulas from './mapearVerticesCelulas.js'
import refinamentoCelulas from './refinamentoCelulas.js'
import desenharGradiente from './desenharGradiente.js'
import initAgentes from './initAgentes.js'



// Declaração de variaveis
let parametros = { 
    dimensoes: { x: 1, y: 1, z: 1 },
    discretizador: { x: 1, y: 1, z: 1 },
    refinamento: { x: 1, y: 1, z: 1 },
    mostrarPontos: true,
    mostrarLinhas: true,
    calcular: 2,
    gradiente: 2,
    fluxo: 2,
    deformar: 2,
    refinar: 2
}

let canvas, camera, cena, renderer, group, estrutura, esferas
let malha, pontos, conexoes, celulas, malhaCelulas, matrizes, cameraZ, rodar
let agentes
let inicio = 0
let final = 0
let passo = 0


let body = document.body
let nav, navItens, navLinks, next, before, bottom
let etapas = [
    { titulo: 'DISCRETIZAÇÃO', conteudo: null },
    { titulo: 'DIMENSIONAMENTO', conteudo: null },
    { titulo: 'ISOVALORES', conteudo: null },
    { titulo: 'FLUXO', conteudo: null },
    { titulo: 'DEFORMAÇÃO', conteudo: null }
]






// App principal
init()
function init() {
    initGui()
    initEnv()
    ajustarMalha()
    initPagina()
    window.addEventListener( 'resize', resize )
    loop()

}
function loop() {
    group.rotation.y += rodar.x
    group.rotation.x += rodar.y
    group.rotation.z += rodar.z
    render()
    
    if ( agentes != null ) {
        for ( let agente of agentes ) {
            let max = agente.path.length * 6
            agente.way += agente.passo
            agente.mesh.geometry.setDrawRange( 0, agente.way )
            if ( agente.way >= max ) {
                agente.way = 0
            }
        }
}
    requestAnimationFrame( loop )
}


// Ferramentas de Modelagem
function ajustarMalha() {
    initCena()
    initCamera()
    initIluminar()
    parametros.refinamento.x = parametros.refinamento.y = parametros.refinamento.z = 1
    matrizes = null
    malha = initGeometria( parametros )
    pontos = initPontos( malha )
    pontos = addConexoesPontos( malha, pontos )
    rebubinarMalha()
    
    rodar =  { x: .004, y: .004, z: .004 }
    
    rebubinarGrupos()

    desenharGradiente( estrutura, malhaCelulas, malha, matrizes, 0 )
    desenharPontos( estrutura, pontos, malha )
    desenharConexoes( estrutura, conexoes )
    desenharCelulas( celulas, esferas, estrutura, malha )

}
function calcularMalha() {
    console.log( 'okay222222' )
    matrizes = initMatrizes( pontos, conexoes )
    pontos = adicionarVetoresNosPontos( pontos, matrizes )
    pontos = adicionarCoresNosPontos( pontos, matrizes )

    rebubinarMalha()
    colorirMalha()

    desenharVetores( estrutura, pontos )
    desenharPontos( estrutura, pontos, malha )
    desenharConexoes( estrutura, conexoes )
    //desenharGradiente( estrutura, malhaCelulas, malha, matrizes, .2 )
    rodar = { x: .002, y: 0, z: 0 }

}
function desenharMalhaCalculada() {
    parametros.refinamento.x = parametros.dimensoes.x <= 3 ? 6 : (parametros.dimensoes.x * 2 - 3 )
    parametros.refinamento.y = parametros.dimensoes.y <= 3 ? 6 : (parametros.dimensoes.y * 2 - 3 )
    parametros.refinamento.z = parametros.dimensoes.z <= 3 ? 6 : (parametros.dimensoes.z * 2 - 3 )
    rebubinarMalha()
    colorirMalha()

    //desenharVetores( estrutura, pontos )
    desenharGradiente( estrutura, malhaCelulas, malha, matrizes, .2 )
    rodar = { x: .0025, y: 0, z: 0 }

}
function desenharFluxo() {
    parametros.refinamento.x = parametros.refinamento.y = parametros.refinamento.z = 4
    desenharMalhaCalculada()
    rebubinarMalha()
    colorirMalha()
    //desenharVetores( estrutura, pontos )
    //desenharGradiente( estrutura, malhaCelulas, malha, matrizes )
    agentes = initAgentes( agentes, estrutura, parametros, malha, malhaCelulas )
    //desenharConexoes( estrutura, conexoes )
    //desenharGradiente( estrutura, malhaCelulas, malha, matrizes, .02 )
    desenharPontos( estrutura, pontos, malha )
    rodar = { x: .003, y: 0, z: 0 }

}
function desenharMalhaDeformada() {
    pontos = deformarPontos( pontos )
    conexoes = initConexoes( pontos )
    colorirMalha()
    desenharVetores( estrutura, pontos )
    desenharConexoes( estrutura, conexoes )
    desenharPontos( estrutura, pontos, malha )

    
}
function rebubinarMalha() {
    conexoes = initConexoes( pontos )
    celulas = initCelulas( malha )
    celulas = addConexoesCelulas( malha, pontos, celulas )
    celulas = mapearVerticesCelulas( celulas )
    malhaCelulas = refinamentoCelulas( celulas, parametros.refinamento, matrizes )
}
function rebubinarGrupos() {
    group = new THREE.Group
    cena.add(group)
    estrutura = new THREE.Group
    group.add(estrutura)
    //group.rotation.x = 5
    //group.rotation.z = 8    
    estrutura.position.set( -malha.dimensoes.totais.x/2, -malha.dimensoes.totais.y/2, -malha.dimensoes.totais.z/2 )
    esferas = new THREE.Group()
}
function colorirMalha() {
    initCena()
    initIluminar()
    rebubinarGrupos()
    //desenharPontos( estrutura, pontos, malha )
    //desenharConexoes( estrutura, conexoes )

}






// Configurações do ambiente 3d
function initCanvas() {
    canvas = document.getElementById( 'canvas' )
    console.log( '2.1 - instanciando Canvas' )
}
function initCamera() {
    camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 1, 4000 )
    
    cameraZ = ((parametros.dimensoes.x > parametros.dimensoes.y ? (parametros.dimensoes.x > parametros.dimensoes.z ? parametros.dimensoes.x : (parametros.dimensoes.z)) : parametros.dimensoes.y))
    
    camera.position.z = (cameraZ)* 8 + 80

    let control = new OrbitControls( camera, canvas )
    control.minDistance = 10
    control.maxDistance = 1000
    console.log( '2.2 - instanciando Camera' )
}
function initCena() {
    cena = new THREE.Scene()
    console.log( '2.3 - instanciando Cena' )
}
function initIluminar() {
    let light = new THREE.HemisphereLight(0xffffff, 0xffffff, .5)
         
    let backLight = new THREE.DirectionalLight(0xffffff, .2);
    backLight.position.set(-10, 20, 50);
    backLight.castShadow = true;

    let lightProbe = new THREE.LightProbe();

    const dirLight = new THREE.DirectionalLight( 'white', .2 );
    dirLight.position.set(10, 10, 10);
    dirLight.castShadow = true;
    dirLight.shadow.camera.top = 2;
    dirLight.shadow.camera.bottom = - 2;
    dirLight.shadow.camera.left = - 2;
    dirLight.shadow.camera.right = 2;
    dirLight.shadow.camera.near = 0.1;
    dirLight.shadow.camera.far = 40;

    const light2 = new THREE.PointLight( 0xff2200, 0.2 );
	light2.position.set( - 100, - 100, - 100 );
	cena.add( light2 )

    addShadowedLight( 1, 1, 1, 0xffffff, .1 )
    addShadowedLight( 0.5, 1, - 1, 0xffffff, .5 )


    function addShadowedLight( x, y, z, color, intensity ) {

        const directionalLight = new THREE.DirectionalLight( color, intensity );
        directionalLight.position.set( x, y, z );
        cena.add( directionalLight );
    
        directionalLight.castShadow = true;
    
        const d = 1;
        directionalLight.shadow.camera.left = - d;
        directionalLight.shadow.camera.right = d;
        directionalLight.shadow.camera.top = d;
        directionalLight.shadow.camera.bottom = - d;
    
        directionalLight.shadow.camera.near = 1;
        directionalLight.shadow.camera.far = 4;
    
        directionalLight.shadow.mapSize.width = 1024;
        directionalLight.shadow.mapSize.height = 1024;
    
        directionalLight.shadow.bias = - 0.001;
    
    }

    cena.add(dirLight);    
    cena.add(lightProbe );    
    cena.add(backLight);
    cena.add(light);
}
function initRenderer() {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setPixelRatio( window.devicePixelRatio )
    renderer.setSize( window.innerWidth, window.innerHeight )
    renderer.outputEncoding = THREE.sRGBEncoding
    canvas.appendChild( renderer.domElement )
    console.log( '2.4 - instanciando Renderer' )
}
function initEnv() {
    console.log( '2 - instanciando Ambiente' )
    initCanvas()
    initCamera()
    initCena()
    initIluminar()
    initRenderer()

}
function render() {
    renderer.render( cena, camera )
    //console.log( '10 - atualizando o Renderizador' )
}
function resize() {
    renderer.setSize( window.innerWidth, window.innerHeight )
    camera.aspect = window.innerWidth / window.innerHeight
    camera.updateProjectionMatrix()
    console.log( '7 - ajustando Tela' )
}




// Debugador
function initGui() {
    const gui = new GUI()
    gui.add( parametros.dimensoes, 'x', 1, 10, 1 ).onChange( event => { ajustarMalha() })
    gui.add( parametros.dimensoes, 'y', 1, 10, 1 ).onChange( event => { ajustarMalha() })
    gui.add( parametros.dimensoes, 'z', 1, 10, 1 ).onChange( event => { ajustarMalha() })
    gui.add( parametros.discretizador, 'x', 1, 4, 1 ).onChange( event => { ajustarMalha() })
    gui.add( parametros.discretizador, 'y', 1, 4, 1 ).onChange( event => { ajustarMalha() })
    gui.add( parametros.discretizador, 'z', 1, 4, 1 ).onChange( event => { ajustarMalha() })
    /*
    gui.add( parametros, 'calcular', 1, 2 ).onChange( event => { calcularMalha() })
    gui.add( parametros, 'gradiente', 1, 2 ).onChange( event => { desenharMalhaCalculada() })
    gui.add( parametros, 'fluxo', 1, 2 ).onChange( event => { desenharFluxo() })
    gui.add( parametros, 'deformar', 1, 2 ).onChange( event => { desenharMalhaDeformada() })
    */
    console.log( '1 - instanciando Configurações' )
}



function initPagina() {
    nav = initNav( body )
    navItens = initNavItem( nav, etapas )
    navLinks = initNavLinks( navItens, etapas )
    addLintenerNav( navLinks )

    /*
    bottom = criarElemento( 'div', { class: 'bottom' } )
    body.append( bottom )
    */
   /*
    let info = criarElemento( 'div', { class: 'info' } )
    info.append( 'i' )
    body.append( info )
    */
    //next = criarElemento( 'div', { class: 'next' } )
    //next.append( 'PROXIMA ETAPA >' )
    //body.append( next )

    next = initNext( body )
    before = initBefore( body )
    addListenerNext( next )
    addListenerBefore( before )
}
function addListenerNext( next ) { 
    next.addEventListener( 'mouseover', event => executarNext( event.target ) )   
}
function addListenerBefore( before ) { 
    before.addEventListener( 'mouseover', event => executarBefore( event.target ) )   
}

function executarNext( target ) {
    if ( matrizes == null ) {
        calcularMalha()
        navegarPontos( navLinks[1].a, navLinks )
    } else if ( rodar.x == .002 ) {
        desenharMalhaCalculada()
        navegarPontos( navLinks[2].a, navLinks )
    } else if ( rodar.x == .0025  ) {
        desenharFluxo()
        navegarPontos( navLinks[3].a, navLinks )
    } else if ( rodar.x == .003  ) {
        desenharMalhaDeformada()
        navegarPontos( navLinks[4].a, navLinks )
    }  
}

function executarBefore( target ) {
    if ( rodar.y == 0 || rodar.z ==0  ) {
        ajustarMalha()
        navegarPontos( navLinks[0].a, navLinks )
    } 
}

function initNext( body ) {
    let next = criarElemento( 'div', { class: 'next' } )
    next.append( '❯' )
    body.append( next )
    return next
}
function initBefore( body ) {
    let before = criarElemento( 'div', { class: 'before' } )
    before.append( '❮' )
    body.append( before )
    return before
}


function initNav( body ) {
    let nav = criarElemento( 'nav', { class: 'nav' } )
    body.append( nav )
    return nav
}
function initNavItem( nav, etapas ) {
    let navItens = []
    for ( let item of etapas ) {
        let navItem
        navItem = criarElemento( 'div', { class: `nav-item` } )
        nav.append( navItem )
        navItens.push( navItem )
    }
    return navItens
}
function initNavLinks( navItens, etapas ) {
    let navLinks = []
    for ( let i in etapas ) {
        let a, span
        if ( i == 0 ) {
            a = criarElemento( 'a', { class: `nav-link nav-link-selected`, href: `#` } )
        } else {
            a = criarElemento( 'a', { class: `nav-link`, href: `#` } )
        }
        
        span = criarElemento( 'span', { class: 'nav-label' } )
        span.append( etapas[i].titulo )

        navItens[i].append( a )
        navItens[i].append( span )
        navLinks.push( { a, span } )
    }
    console.log( navLinks )
    return navLinks
}

function addLintenerNav( navLinks ) {
    for ( let item of navLinks ) {
        item.a.addEventListener( 'mouseover', event => { navegarPontos( event.target, navLinks ) } )
    }
}

function navegarPontos( target, links ) {
    for ( let link of links ) { link.a.setAttribute( 'class', `nav-link` ) }
    target.setAttribute( 'class', `nav-link nav-link-selected` )
}

function criarElemento( nome, atributos ) {
    const elemento = document.createElement( nome )
    const atributosAsArrays = Object.entries( atributos )
    atributosAsArrays.forEach( ([ key, valor ]) => elemento.setAttribute( key, valor ) )
    return elemento
}

