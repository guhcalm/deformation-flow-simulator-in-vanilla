function initAgente() {
    //console.log( "Criando agente..." )
    let agente = { pos: null, cor: null, vetor: null, path: [] }
    //console.log( "... o agente foi criado" )
    return agente
}
export default initAgente