function addConexoesPontos( malha, pontos ) {
    // organizando variaveis...
    let dx, dy, dz
    dx = malha.dimensoes.discretas.x
    dy = malha.dimensoes.discretas.y
    dz = malha.dimensoes.discretas.z
    let maximaDistancia = Math.sqrt( dx * dx + dy * dy + dz * dz )
    // ... variaveis organizadas.

    for ( let a of pontos ) {
        for ( let b of pontos ) {
            let lx, ly, lz, distancia
            lx = Math.abs( ( b.posicionamento.x ) - ( a.posicionamento.x ) )
            ly = Math.abs( ( b.posicionamento.y ) - ( a.posicionamento.y ) )
            lz = Math.abs( ( b.posicionamento.z ) - ( a.posicionamento.z ) )

            distancia = Math.sqrt( lx * lx + ly * ly + lz * lz )
            if ( distancia <= maximaDistancia && distancia > 0 ) {
                a.conexoes.identificador.push( b.identificador )
            }
        }
    }

    return pontos
}

export default addConexoesPontos





                 /*
                if ( lx > 0 && ly > 0 && lz > 0 ) {
                    a.conexoes.identificador.push( b.identificador )
                }
                //if ( distancia <= ( dz > dy ? (dy > dx ? dx : dy) : dz ) ) {a.conexoes.identificador.push( b.identificador )}
                
                if ( (distancia) == (dx) ) {
                    a.conexoes.identificador.push( b.identificador )
                }
                if ( (distancia) == (dy)  ) {
                    a.conexoes.identificador.push( b.identificador )
                }
                if ( (distancia) == (dz) ) {
                    a.conexoes.identificador.push( b.identificador )
                }*/